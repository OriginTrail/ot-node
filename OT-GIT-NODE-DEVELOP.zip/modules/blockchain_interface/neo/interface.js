module.exports = function() {
  // TODO: NEO interface
  interface = {

  };
  return interface;
}