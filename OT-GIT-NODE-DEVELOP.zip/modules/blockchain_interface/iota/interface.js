module.exports = function() {
  // TODO: IOTA interface
  interface = {

  };

  return interface;
}